<style>
    .error{
        color:red;
    }
</style>












<form id="calculator" >
	
    <input type="radio" name="scale" value="Lbs(inch)">
    <label for="html">Lbs(inch)</label><br>
    <input type="radio"  name="scale" value="kg()cm">
    <label for="css">Kg(cm)</label><br>
    <label for="scale" class="error"></label>
	<hr>
    
	<div>
		
		<span class="length-input" ><span>Length:</span> <input type="number" id="calc-length" name="length"><br><label for="calc-length" class="error"></label></span><br>
		<span class="length-input" ><span> Width:</span> <input type="number" id="calc-width" name="width"><br><label for="calc-width" class="error"></label></span><br>
	    <span class="length-input" ><span>Height:</span> <input type="number" id="calc-height" name="height"><br><label for="calc-height" class="error"></label></span><br>
        <span class="length-input" ><span>Quantity:</span> <input type="number" id="calc-qun" name="quantity"><br><label for="calc-qun" class="error"></label></span><br>
	</div>
	<hr>
	<button type="submit" >calculate</button>
	
	
</form>

<input id="calculate-cm" type="text" >Volume (Cm)<br>
	<input id="calculate-lbs" type="text" >Volume (lbs)

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.19.3/jquery.validate.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>


<script>


   


    $(document).ready(function () {
        // e.preventDefault();
    $("#calculator").validate({
        rules: {
            scale: {
                required: true
            },
            height: {
                required: true
            },
            width: {
                required: true
            },
            length: {
                required: true
            },
            quantity: {
                required: true
            },
            
        },
        messages: {
            scale: {
                required: "Please select scale"
            },
            height: {
                required: "Please enter height"
            },
            width: {
                required: "Please enter width"
            },
            length: {
                required: "Please enter length"
            },
            quantity: {
                required: "Please enter quantity"
            },
        },submitHandler: function(form) {

            const length=$('#calc-width').val();
       const width=$('#calc-length').val();
       const heigth=$('#calc-height').val();
       const quantity=$('#calc-qun').val();
       const check_value=$('input[name="scale"]:checked').val();
      
    if(check_value == 'Lbs(inch)'){
        const volume_inch=(length * width * heigth)/166;
       
        $('#calculate-lbs').val(volume_inch)
    }else{
        const volume_cm=(length*width*heigth)/6000;
        $('#calculate-cm').val(volume_cm)
       }              

                                                        
        }
       
    });
});
</script>